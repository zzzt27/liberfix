<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- Font Awesome -->
<link rel="stylesheet" href="css/font-awesome.min.css">
<!-- Bootstrap CSS -->
<link rel="stylesheet" href="lib/vendor/bootstrap/css/bootstrap.min.css">
<!-- Main CSS -->
<link rel="stylesheet" href="css/style.css">
<link rel="icon" type="image/png" href="img/icon1.png">
<title>Libernet | <?= $title ?></title>