<footer class="text-center">
    <font color="white">© 2021 <a href="https://github.com/lutfailham96/libernet">Libernet</a> v1.5.3. All rights reserved.</a>
</footer>
